#pragma once
#include<WinSock2.h>
#include<thread>
void dealpacks(SOCKET&);
extern bool busy;

